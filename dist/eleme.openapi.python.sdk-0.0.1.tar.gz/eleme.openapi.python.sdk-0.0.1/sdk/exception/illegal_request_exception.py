
class IllegalRequestException(Exception):pass
    