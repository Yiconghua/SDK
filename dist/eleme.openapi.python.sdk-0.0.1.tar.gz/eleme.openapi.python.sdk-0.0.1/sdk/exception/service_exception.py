
class ServiceException(Exception):pass
    