
class MethodNotAllowedException(Exception):pass
    