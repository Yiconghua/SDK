
class InvalidSignatureException(Exception):pass
    