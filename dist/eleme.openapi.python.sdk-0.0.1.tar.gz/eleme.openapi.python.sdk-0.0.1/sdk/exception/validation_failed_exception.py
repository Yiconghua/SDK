
class ValidationFailedException(Exception):pass
    