
class SystemException(Exception):pass
    