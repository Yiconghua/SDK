
class InvalidTimestampException(Exception):pass
    