
class PermissionDeniedException(Exception):
    pass
