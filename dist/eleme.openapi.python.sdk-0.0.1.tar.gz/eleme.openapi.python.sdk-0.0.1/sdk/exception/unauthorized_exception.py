
class UnauthorizedException(Exception):pass
    