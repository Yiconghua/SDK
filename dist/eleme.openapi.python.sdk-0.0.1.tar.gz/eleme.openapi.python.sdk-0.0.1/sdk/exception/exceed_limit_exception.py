
class ExceedLimitException(Exception):pass
