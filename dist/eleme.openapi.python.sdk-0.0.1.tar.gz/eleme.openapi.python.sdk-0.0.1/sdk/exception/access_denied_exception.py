
class AccessDeniedException(Exception):pass
    