

from setuptools import setup, find_packages

setup(
    name='eleme.openapi.python.sdk',
    version='0.0.1',
    keywords=('eleme', 'openapi'),
    #long_description=open('README.md').read(),
    description='eleme openapi python sdk',
    license='MIT License',
    packages=find_packages(),
    author='David',
    author_email='open.shop@ele.me',
)

